for i in range(10, 16):
    print("i is now {}".format(i))
