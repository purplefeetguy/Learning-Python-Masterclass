# for i in range(10):
#     print("i is now {}".format(i))

i = 0
while True:
    print("i is now {}".format(i))
i += 1
